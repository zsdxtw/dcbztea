/** 模块标识 */
export enum ModuleKey {
  DASHBOARD = 'dashboard',
  PURCHASE = 'purchase',
  SALES = 'sales',
  INVENTORY = 'inventory',
  PRODUCT = 'product',
  FINANCE = 'finance',
  STATISTICS = 'statistics',
  SETTINGS = 'settings',
  PERSONNEL = 'personnel',
}

/** 六大茶类 */
export enum TeaCategory {
  GREEN = 'green',
  WHITE = 'white',
  YELLOW = 'yellow',
  OOLONG = 'oolong',
  RED = 'red',
  DARK = 'dark',
  FLOWER = 'flower',
}

/** 订单状态 */
export enum OrderStatus {
  PENDING = 'pending',
  APPROVED = 'approved',
  SHIPPING = 'shipping',
  COMPLETED = 'completed',
  CANCELLED = 'cancelled',
}

/** 库存状态 */
export enum StockStatus {
  SUFFICIENT = 'sufficient',
  LOW = 'low',
  INSUFFICIENT = 'insufficient',
}

/** 侧边栏菜单项 */
export interface MenuItem {
  key: string;
  label: string;
  icon: React.ReactNode;
  children?: MenuItem[];
}

/** 模块配置 */
export interface ModuleConfig {
  key: ModuleKey;
  label: string;
  menus: MenuItem[];
}

/** 趋势数据 */
export interface TrendData {
  direction: 'up' | 'down';
  value: string;
  label?: string;
}

/** 统计卡片数据 */
export interface StatCardData {
  label: string;
  value: string;
  unit?: string;
  trend?: TrendData;
  icon: React.ReactNode;
}

/** 订单项 */
export interface OrderItem {
  id: string;
  code: string;
  partner: string;
  product: string;
  teaCategory: TeaCategory;
  quantity: string;
  amount: string;
  status: OrderStatus;
}

/** 商品项 */
export interface ProductItem {
  id: string;
  name: string;
  spec: string;
  teaCategory: TeaCategory;
  price: number;
  unit: string;
}

/** 库存项 */
export interface StockItem {
  id: string;
  productName: string;
  teaCategory: TeaCategory;
  warehouse: string;
  quantity: string;
  status: StockStatus;
}

/** 预警项 */
export interface AlertItemData {
  name: string;
  stock: string;
  level: 'danger' | 'warning';
}

/** 待办项 */
export interface TodoItemData {
  text: string;
  time: string;
  done: boolean;
}

/** 按钮变体 */
export type ButtonVariant = 'primary' | 'secondary' | 'ghost' | 'danger';
export type ButtonSize = 'default' | 'sm';

/** 状态标签变体 */
export type StatusVariant = 'success' | 'warning' | 'error' | 'info' | 'default';

/** 通知类型 */
export enum NotificationType {
  SYSTEM = 'system',
  ORDER = 'order',
  QUALITY = 'quality',
  INVENTORY = 'inventory',
}

/** 质检结果 */
export enum QualityResult {
  PENDING = 'pending',
  QUALIFIED = 'qualified',
  UNQUALIFIED = 'unqualified',
}

/** 报价状态 */
export enum QuotationStatus {
  PENDING_REPLY = 'pending_reply',
  QUOTED = 'quoted',
  EXPIRED = 'expired',
  CONVERTED = 'converted',
}

/** 通知项 */
export interface NotificationItem {
  id: string;
  type: NotificationType;
  title: string;
  content: string;
  time: string;
  read: boolean;
}

/** 质检项 */
export interface QualityItem {
  id: string;
  batchCode: string;
  productName: string;
  teaCategory: TeaCategory;
  grade: string;
  moisture: number;
  ash: number;
  pesticideResidue: number;
  sensory: string;
  result: QualityResult;
}

/** 报价项 */
export interface QuotationItem {
  id: string;
  quotationCode: string;
  customer: string;
  teaCategory: TeaCategory;
  grade: string;
  unitPrice: number;
  quantity: number;
  amount: number;
  validUntil: string;
  status: QuotationStatus;
}

/** 溯源步骤 */
export interface TraceStep {
  stage: string;
  location: string;
  date: string;
  operator: string;
}

/** 溯源项 */
export interface TraceabilityItem {
  id: string;
  batchCode: string;
  productName: string;
  teaCategory: TeaCategory;
  grade: string;
  source: string;
  inboundDate: string;
  status: StockStatus;
  traceSteps: TraceStep[];
}

/** 品级项 */
export interface GradeItem {
  id: string;
  name: string;
  applicableCategories: TeaCategory[];
  pricingFactor: number;
  sensoryStandard: string;
  productCount: number;
  active: boolean;
}

/** 茶类详情 */
export interface TeaCategoryDetail {
  category: TeaCategory;
  introduction: string;
  process: string;
  storage: string;
  flavor: string;
  representativeTeas: string[];
  productCount: number;
}

/** 退货状态 */
export enum ReturnStatus {
  PENDING = 'pending',
  APPROVED = 'approved',
  COMPLETED = 'completed',
  REJECTED = 'rejected',
}

/** 退货项 */
export interface ReturnItem {
  id: string;
  code: string;
  originalOrder: string;
  partner: string;
  product: string;
  quantity: string;
  amount: string;
  reason: string;
  status: ReturnStatus;
}

/** 预警类型 */
export enum AlertType {
  STOCK_LOW = 'stock_low',
  SHELF_LIFE = 'shelf_life',
  SLOW_MOVING = 'slow_moving',
  STOCK_HIGH = 'stock_high',
  ENVIRONMENT = 'environment',
  PRICE = 'price',
  SUPPLY = 'supply',
}

/** 预警规则项 */
export interface AlertRuleItem {
  id: string;
  name: string;
  type: AlertType;
  condition: string;
  productCount: number;
  enabled: boolean;
  triggered: boolean;
}

/** 收款/付款状态 */
export enum PaymentStatus {
  PAID = 'paid',
  PENDING = 'pending',
  OVERDUE = 'overdue',
  RECEIVED = 'received',
}

/** 发票状态 */
export enum InvoiceStatus {
  ISSUED = 'issued',
  RECEIVED = 'received',
  PENDING = 'pending',
  VOID = 'void',
}

/** 发票类型 */
export enum InvoiceType {
  OUTPUT = 'output',
  INPUT = 'input',
}

/** 库位状态 */
export enum LocationStatus {
  OCCUPIED = 'occupied',
  EMPTY = 'empty',
  MAINTENANCE = 'maintenance',
}

/** 用户状态 */
export enum UserStatus {
  ACTIVE = 'active',
  INACTIVE = 'inactive',
}

/** 备份状态 */
export enum BackupStatus {
  SUCCESS = 'success',
  FAILED = 'failed',
}

/** 品牌等级 */
export enum BrandLevel {
  S = 'S',
  A = 'A',
  B = 'B',
  C = 'C',
}

/** 品牌状态 */
export enum BrandStatus {
  ACTIVE = 'active',
  INACTIVE = 'inactive',
}

/** 品牌项 */
export interface BrandItem {
  id: string;
  code: string;
  name: string;
  logo: string;
  owner: string;
  introduction: string;
  requirements: string;
  policy: string;
  series: string[];
  trademarkCert: string[];
  jdStoreUrl: string;
  tmallStoreUrl: string;
  contactPerson: string;
  contactPhone: string;
  /** 省份 */
  province?: string;
  /** 城市 */
  city?: string;
  /** 区县 */
  district?: string;
  address: string;
  mainCategories: string[];
  productCount: number;
  supplierCount: number;
  website: string;
  cooperationDate: string;
}

/** 茶叶商品 */
export interface TeaProduct {
  id: string;
  code: string;
  name: string;
  category: string;
  categories: string[];
  brand: string;
  series: string;
  packageUnit: string;
  barcode69: string;
  model: string;
  spec: string;
  /** 每份规格 */
  perUnitSpec: {
    netWeight: number;       // 净重
    netWeightUnit: string;   // 净重单位
    grossWeight: number;     // 毛重
    grossWeightUnit: string; // 毛重单位
    length: number;          // 长
    width: number;           // 宽
    height: number;          // 高
    dimensionUnit: string;   // 尺寸单位
  };
  /** 每箱规格（箱规） */
  perBoxSpec: {
    quantity: number;        // 每箱数量
    netWeight: number;       // 净重 = 每份净重 × 数量
    netWeightUnit: string;   // 净重单位
    grossWeight: number;     // 毛重 = 每份毛重 × 数量
    grossWeightUnit: string; // 毛重单位
    length: number;          // 长
    width: number;           // 宽
    height: number;          // 高
    dimensionUnit: string;   // 尺寸单位
  };
  weight: number;
  volume: { length: number; width: number; height: number };
  quantityPerUnit: number;
  grade: string;
  origin: string;
  shelfLife: number;
  taxRate: number;
  packageList: string;
  marketPrice: number;
  tmallPrice: number;
  tmallUrl: string;
  jdPrice: number;
  jdUrl: string;
  /** 销售价：当前系统内各商品标准的对外销售价 */
  salesPrice: number;
  shelfStatus: 'on' | 'off';
  purchaseStatus: 'available' | 'stopped';
  productionStatus: 'producing' | 'stopped';
  mainImages: string[];
  detailImages: string[];
  displayImageIndex: number;
  stockAlert: number;
  stock: number;
  reservedStock: number;
  totalSales: number;
  features: string;
  includesTeaware: boolean;
  remark: string;
}

/** 茶人类型 */
export type TeaProfessionalType = 'tea_artist' | 'tea_evaluator' | 'tea_maker' | 'tea_sommelier';

/** 茶人证书 */
export interface TeaCertificate {
  name: string;
  level: string;
  issuer: string;
  issueDate: string;
  certNo: string;
}

/** 茶人获奖记录 */
export interface TeaAward {
  name: string;
  level: string;
  awardDate: string;
  organization: string;
}

/** 茶人服务报价 */
export interface TeaServiceQuote {
  serviceType: string;
  duration: string;
  price: number;
  unit: string;
  remark: string;
}

/** 茶人 */
export interface TeaProfessional {
  id: string;
  name: string;
  type: TeaProfessionalType[];
  gender: 'male' | 'female';
  photo: string;
  region: string;
  /** 省份 */
  province?: string;
  /** 城市 */
  city?: string;
  /** 区县 */
  district?: string;
  height: number;
  weight: number;
  birthDate: string;
  phone: string;
  email: string;
  idCard: string;
  address: string;
  certificates: TeaCertificate[];
  specialties: string[];
  awards: TeaAward[];
  serviceQuotes: TeaServiceQuote[];
  introduction: string;
  status: 'active' | 'inactive';
  /** 结算信息（户名、卡号、开户银行、开户行号） */
  settlement?: EmployeeSettlement;
  /** 是否带货 */
  isStreamer?: boolean;
}

/** 供应商类型 */
export type SupplierType = 'brand' | 'partner';

/** 供应商评价等级 */
export type SupplierGrade = 'S' | 'A' | 'B' | 'C' | 'D';

/** 税务类型 */
export type TaxType = 'small' | 'general';

/** 结算方式 */
export type SettlementMethod = 'period' | 'prepaid' | 'invoice' | 'monthly' | 'quarterly';

/** 快递费结算方式 */
export type ShippingSettlement = 'free' | 'not_free_fixed' | 'not_free_ratio' | 'not_free_bear';

/** 仓库信息 */
export interface SupplierWarehouse {
  id: string;
  name: string;
  province?: string;
  city?: string;
  district?: string;
  address: string;
  contactPerson: string;
  contactPhone: string;
  isDefault: boolean;
}

/** 仓库归属类型：独立仓库（自有的纯仓库）/ 门店仓库（自有的在茶叶门店的仓库）/ 合作仓库（供应商的合作仓库） */
export type WarehouseCategory = 'independent' | 'store' | 'partner';

/** 仓库信息（仓库设置模块统一结构） */
export interface Warehouse {
  id: string;
  name: string;
  code: string;
  address: string;
  /** 省份 */
  province?: string;
  /** 城市 */
  city?: string;
  /** 区县 */
  district?: string;
  manager: string;
  phone: string;
  category: WarehouseCategory;
  enabled: boolean;
  isDefault: boolean;
  /** 合作仓库关联的供应商 ID（独立/门店仓库为空） */
  supplierId?: string;
  /** 合作仓库关联的供应商名称（独立/门店仓库为空） */
  supplierName?: string;
}

/** 开票信息 */
export interface InvoiceInfo {
  title: string;
  taxNo: string;
  taxRate: number;
  address?: string;
  phone?: string;
  bankName?: string;
  bankAccount?: string;
}

/** 结算银行账号 */
export interface BankAccount {
  accountName: string;
  accountNo: string;
  bankName: string;
  bankNo: string;
  remark?: string;
}

/** 客户类型 */
export type CustomerType = 'direct' | 'channel' | 'personal' | 'platform' | 'guest';

/** 客户分组 */
export type CustomerGroup = 'enterprise' | 'personal';

/** 下单人（直营客户下的联系人） */
export interface OrderContact {
  /** 下单人 ID */
  id: string;
  /** 姓名 */
  name: string;
  /** 部门 */
  department?: string;
  /** 手机号码 */
  phone?: string;
  /** 地址 */
  address?: string;
  /** 备注 */
  remark?: string;
  /** 是否由订单自动创建（销售订单收件人不在下单人内时自动添加） */
  autoCreated?: boolean;
}

/** 平台结算账户 */
export interface PlatformBankAccount {
  accountName: string;
  accountNo: string;
  bankName: string;
  bankNo: string;
}

/** 平台发票信息 */
export interface PlatformInvoiceInfo {
  invoiceEntity: string;
  taxNo: string;
  taxRate: string;
}

/** 客户结算账户（与平台结算账户结构一致） */
export type CustomerBankAccount = PlatformBankAccount;

/** 客户发票信息（与平台发票信息结构一致） */
export type CustomerInvoiceInfo = PlatformInvoiceInfo;

/** 人员角色类型：员工 / 茶人 / 带货人 */
export type PersonRoleType = 'employee' | 'tea_professional' | 'streamer';

/** 分润比例设置 */
export interface ProfitShareConfig {
  /** 拓客人分润比例（0-100） */
  developerRatio: number;
  /** 维护人分润比例（0-100） */
  maintainerRatio: number;
  /** 跟单人分润比例（0-100） */
  followerRatio: number;
}

/** 直营客户分子机构 */
export interface CustomerSubOrganization {
  id: string;
  /** 机构名称 */
  name: string;
  /** 联系人 */
  contactPerson: string;
  /** 联系方式 */
  contactPhone: string;
  /** 省份 */
  province?: string;
  /** 城市 */
  city?: string;
  /** 区县 */
  district?: string;
  /** 详细地址 */
  address: string;
  /** 拓客人 ID */
  developerId?: string;
  /** 拓客人类型 */
  developerType?: PersonRoleType;
  /** 拓客人姓名（冗余，便于展示） */
  developerName?: string;
  /** 维护人 ID */
  maintainerId?: string;
  /** 维护人类型 */
  maintainerType?: PersonRoleType;
  /** 维护人姓名（冗余，便于展示） */
  maintainerName?: string;
  /** 备注 */
  remark?: string;
}

/** 平台 */
export interface PlatformItem {
  id: string;
  name: string;
  shortName: string;
  /** 平台编号（规则：KHPT-0001） */
  code: string;
  contactPerson: string;
  contactPosition: string;
  contactPhone: string;
  contactAddress: string;
  /** 省份 */
  province?: string;
  /** 城市 */
  city?: string;
  /** 区县 */
  district?: string;
  cooperationDate: string;
  /** 支付保证金（单位：元，平台客户交纳的保证金，联动记入财务-其他应收款-暂付款项） */
  deposit?: number;
  /** 保证金应收日期 */
  depositDueDate?: string;
  /** 拓客人 ID（原主办人，负责该平台客户的拓展与维护，可为员工/茶人/带货人） */
  developerId?: string;
  /** 拓客人类型 */
  developerType?: PersonRoleType;
  /** 拓客人姓名（冗余，便于展示） */
  developerName?: string;
  bankAccounts: PlatformBankAccount[];
  invoiceInfos: PlatformInvoiceInfo[];
  status: 'active' | 'inactive';
  remark?: string;
}

/** 客户 */
export interface CustomerItem {
  id: string;
  name: string;
  /** 客户简称 */
  shortName?: string;
  /** 客户编号（直营KHZY/渠道KHQD-XXXXX） */
  customerCode?: string;
  type: CustomerType;
  /** 是否经平台（仅 type='direct' 时有效）：true=经平台，false=无平台 */
  viaPlatform?: boolean;
  region: string;
  /** 省份 */
  province?: string;
  /** 城市 */
  city?: string;
  /** 区县 */
  district?: string;
  contactPerson: string;
  contactPhone: string;
  contactEmail?: string;
  contactAddress?: string;
  level: string;
  orders: number;
  totalAmount: number;
  /** 直营客户关联的平台ID列表；渠道客户为空 */
  platformIds: string[];
  /** 平台扣点映射（仅"带平台方"的直营客户设置，键为平台ID，值为扣点如"8%"；扣点跟随平台，同一客户不同平台可有不同扣点） */
  platformCommissionRates?: Record<string, string>;
  /** 拓客人 ID（原主办人，负责客户拓展，可为员工/茶人/带货人） */
  developerId?: string;
  /** 拓客人类型 */
  developerType?: PersonRoleType;
  /** 拓客人姓名（冗余，便于展示） */
  developerName?: string;
  /** 维护人 ID（负责客户维护，可为员工/茶人/带货人） */
  maintainerId?: string;
  /** 维护人类型 */
  maintainerType?: PersonRoleType;
  /** 维护人姓名（冗余，便于展示） */
  maintainerName?: string;
  /** 跟单人 ID（负责订单跟进，可为员工/茶人/带货人） */
  followerId?: string;
  /** 跟单人类型 */
  followerType?: PersonRoleType;
  /** 跟单人姓名（冗余，便于展示） */
  followerName?: string;
  /** 分润比例配置 */
  profitShare?: ProfitShareConfig;
  cooperationDate: string;
  status: 'active' | 'inactive';
  settlementMethod?: string;
  taxNo?: string;
  /** 客户来源 */
  source?: string;
  /** 结算账户列表 */
  bankAccounts?: CustomerBankAccount[];
  /** 发票信息列表 */
  invoiceInfos?: CustomerInvoiceInfo[];
  /** 备注 */
  remark?: string;
  /** 下单人列表（仅 type='direct' 时有效） */
  orderContacts?: OrderContact[];
  /** 分子机构列表（仅 type='direct' 时有效） */
  subOrganizations?: CustomerSubOrganization[];
}

/** 门店（线下茶叶店） */
export interface StoreItem {
  id: string;
  /** 门店编号（MD-XXXX） */
  code: string;
  /** 门店名称 */
  name: string;
  /** 省份 */
  province: string;
  /** 城市 */
  city: string;
  /** 区县 */
  district: string;
  /** 详细地址 */
  address: string;
  /** 店长/负责人 */
  manager: string;
  /** 联系电话 */
  phone: string;
  /** 营业时间 */
  businessHours: string;
  /** 开业日期 */
  openingDate: string;
  /** 门店面积（㎡） */
  area: number;
  /** 营业状态 */
  status: 'active' | 'inactive';
  /** 备注 */
  remark?: string;
}

/** 供应商 */
export interface SupplierItem {
  id: string;
  type: SupplierType;
  name: string;
  unifiedCreditCode: string;
  cooperationAgreements: string[];
  brandAuthAgreements: string[];
  businessLicense: string;
  /** 注册地址-省份 */
  registeredProvince?: string;
  /** 注册地址-城市 */
  registeredCity?: string;
  /** 注册地址-区县 */
  registeredDistrict?: string;
  registeredAddress: string;
  legalRepresentative: string;
  establishmentDate: string;
  registeredCapital: string;
  companyType: string;
  businessScope: string;
  contactPerson: string;
  contactPosition: string;
  /** 联系地址-省份 */
  contactProvince?: string;
  /** 联系地址-城市 */
  contactCity?: string;
  /** 联系地址-区县 */
  contactDistrict?: string;
  contactAddress: string;
  contactPhone: string;
  contactEmail: string;
  warehouses: SupplierWarehouse[];
  taxType: TaxType;
  invoiceInfo: InvoiceInfo;
  cooperationDate: string;
  grade: SupplierGrade;
  mainCategories: string[];
  introduction: string;
  settlementMethod: SettlementMethod;
  bankAccount: BankAccount;
  shippingSettlement: ShippingSettlement;
  shippingFee?: number;
  shippingRemark?: string;
  supportDropship: boolean;
  qualificationStatus: 'qualified' | 'pending' | 'expired';
  paymentTerms: string;
  deliveryCycle: string;
  minOrderAmount: number;
  returnPolicy: string;
  qualityGuarantee: string;
  remark: string;
  status: 'active' | 'inactive';
}

/* ─────────────────────────── 价格体系类型 ─────────────────────────── */

/** 采购价规则：按「商品 + 供应商」维度维护 */
export interface PurchasePriceRule {
  id: string;
  /** 商品 ID */
  productId: string;
  productName: string;
  brand: string;
  category: string;
  /** 供应商 ID */
  supplierId: string;
  supplierName: string;
  /** 市场价（冗余，便于展示对比） */
  marketPrice: number;
  /** 采购价：与供应商商定的进货价格 */
  purchasePrice: number;
  /** 采购折扣率（百分比，如 55 表示 55%） */
  discountRate: number;
  /** 生效日期 */
  validFrom: string;
  /** 失效日期 */
  validTo: string;
  /** 状态 */
  status: 'active' | 'inactive';
  /** 最近调价记录 */
  lastAdjustDate?: string;
  lastAdjustNote?: string;
}

/** VIP 销售价规则：按「商品 + 客户」维度维护 */
export interface VipPriceRule {
  id: string;
  /** 商品 ID */
  productId: string;
  productName: string;
  brand: string;
  category: string;
  /** 客户 ID */
  customerId: string;
  customerName: string;
  /** 客户类型 */
  customerType: string;
  /** 市场价（冗余） */
  marketPrice: number;
  /** 标准销售价（冗余） */
  salesPrice: number;
  /** VIP 销售价 */
  vipPrice: number;
  /** VIP 折扣率（百分比，如 85 表示 85%） */
  discountRate: number;
  /** 生效日期 */
  validFrom: string;
  /** 失效日期 */
  validTo: string;
  /** 状态 */
  status: 'active' | 'inactive';
  /** 备注 */
  remark?: string;
}

/** 采购订单明细项（含采购实价） */
export interface PurchaseOrderItem {
  productId: string;
  name: string;
  spec: string;
  quantity: string;
  /** 市场价（参考） */
  marketPrice: number;
  /** 采购价（系统带出的默认价） */
  purchasePrice: number;
  /** 采购实价：本订单实际成交价格（可调整） */
  actualPurchasePrice: number;
  /** 金额 = 数量 × 采购实价 */
  amount: string;
}

/** 销售订单明细项（含销售实价） */
export interface SalesOrderItem {
  productId: string;
  name: string;
  teaCategory: TeaCategory;
  quantity: string;
  /** 市场价（参考） */
  marketPrice: number;
  /** 默认销售价（VIP价或销售价，系统带出） */
  defaultPrice: number;
  /** 销售实价：本订单实际成交价格（可调整） */
  actualSalesPrice: number;
  /** 价格来源：vip / sales / market */
  priceSource: 'vip' | 'sales' | 'market';
  /** 金额 = 数量 × 销售实价 */
  amount: string;
}

/* ════════════════════════════════════════
 * 组织架构 & 员工管理
 * ════════════════════════════════════════ */

/** 组织节点类型：公司 / 部门 / 团队 */
export type OrgNodeType = 'company' | 'department' | 'team';

/** 组织架构节点 */
export interface OrgNode {
  id: string;
  /** 节点类型 */
  type: OrgNodeType;
  /** 名称 */
  name: string;
  /** 父节点 ID（公司层为空） */
  parentId: string | null;
  /** 负责人姓名 */
  leader?: string;
  /** 排序号 */
  sort: number;
  /** 状态 */
  status: 'active' | 'inactive';
  /** 备注 */
  remark?: string;
}

/** 员工状态 */
export type EmployeeStatus = 'active' | 'inactive' | 'probation';

/** 学习经历阶段 */
export type EducationStage = 'high_school' | 'college' | 'university';

/** 学习经历条目 */
export interface EducationRecord {
  /** 阶段：高中 / 大专 / 大学 */
  stage: EducationStage;
  /** 学校 */
  school: string;
  /** 学院 */
  college: string;
  /** 专业 */
  major: string;
}

/** 员工结算信息 */
export interface EmployeeSettlement {
  /** 卡号 */
  accountNo: string;
  /** 户名 */
  accountName: string;
  /** 开户银行 */
  bankName: string;
  /** 开户行号 */
  bankNo: string;
}

/** 合同文件 */
export interface ContractFile {
  /** 文件名 */
  name: string;
  /** 文件 URL（ObjectURL 或外链） */
  url: string;
  /** 上传时间 */
  uploadedAt: string;
}

/** 员工 */
export interface Employee {
  id: string;
  /** 工号 */
  empNo: string;
  /** 姓名 */
  name: string;
  /** 性别 */
  gender: 'male' | 'female';
  /** 手机号 */
  phone: string;
  /** 邮箱 */
  email?: string;
  /** 部门 ID */
  departmentId: string;
  /** 团队 ID（可选） */
  teamId?: string;
  /** 职位 */
  position: string;
  /** 入职日期 */
  joinDate: string;
  /** 状态 */
  status: EmployeeStatus;
  /** 备注 */
  remark?: string;

  /* ── 身份证信息 ── */
  /** 身份证号 */
  idCardNo?: string;
  /** 身份证图片（正面/反面，ObjectURL 或外链） */
  idCardImages?: string[];
  /** 身份证住址 */
  idCardAddress?: string;
  /** 民族 */
  ethnicity?: string;
  /** 籍贯 */
  nativePlace?: string;
  /** 出生日期 */
  birthDate?: string;

  /* ── 个人信息 ── */
  /** 兴趣爱好 */
  hobbies?: string;
  /** 身高（cm） */
  height?: number;
  /** 体重（kg） */
  weight?: number;
  /** 本地住址 */
  localAddress?: string;

  /* ── 学历信息 ── */
  /** 学历 */
  education?: string;
  /** 学位 */
  degree?: string;
  /** 学习经历（高中/大专/大学可多选） */
  educationRecords?: EducationRecord[];

  /* ── 结算信息 ── */
  /** 结算信息 */
  settlement?: EmployeeSettlement;

  /* ── 合同文件 ── */
  /** 合同文件列表（PDF，最多5个） */
  contracts?: ContractFile[];

  /* ── 紧急联系人 ── */
  /** 紧急联系人姓名 */
  emergencyContactName?: string;
  /** 紧急联系人电话 */
  emergencyContactPhone?: string;
}

/** 带货人 */
export interface Streamer {
  id: string;
  /** 姓名 */
  name: string;
  /** 手机号码 */
  phone: string;
  /** 结算信息（户名、卡号、开户银行、开户行号） */
  settlement: EmployeeSettlement;
  /** 备注 */
  remark?: string;
  /** 关联的茶人 ID（若由茶人联动创建） */
  linkedTeaProfessionalId?: string;
}

/** 订单销售场景（6种情况） */
export type SalesScenario = 1 | 2 | 3 | 4 | 5 | 6;

/** 员工绩效统计（绩效金额 + 绩效利润） */
export interface EmployeePerformance {
  employeeId: string;
  employeeName: string;
  departmentName: string;
  position: string;
  /** 绩效金额 - 作为跟单人的销售金额 */
  followerAmount: number;
  /** 绩效金额 - 作为主办人的销售金额 */
  hostAmount: number;
  /** 绩效金额总额 */
  totalAmount: number;
  /** 绩效利润 - 作为跟单人的利润金额 */
  followerProfit: number;
  /** 绩效利润 - 作为主办人的利润金额 */
  hostProfit: number;
  /** 绩效利润总额 */
  totalProfit: number;
  /** 关联订单数 */
  orderCount: number;
}
